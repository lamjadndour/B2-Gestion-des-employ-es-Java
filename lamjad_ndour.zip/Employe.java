package bref2;

public class Employe {
	private String nom ;
    private int id;
    
    public void setNom(String nom) {
 		this.nom=nom;
 	}
     public void setId(int id) {
  		this.id=id;
  	}
     public String getNom() {
  		return this.nom;
  	}
     public int getId() {
 		return this.id;
 	}
    public void afficher() {
    	
    }
}
